CREATE FUNCTION auto_modified()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  new.modified = now();
  RETURN new;
END;
$$;

